package com.team23.mdpremotecontroller.ui.bluetooth

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import com.team23.mdpremotecontroller.R
import com.team23.mdpremotecontroller.data.bluetooth.BluetoothDevice
import com.team23.mdpremotecontroller.data.bluetooth.BluetoothUiState
import com.team23.mdpremotecontroller.ui.components.SquidButton
import com.team23.mdpremotecontroller.ui.theme.Pink40


@Composable
fun ScanningScreen(
    state: BluetoothUiState,
    onStopScan: () -> Unit,
    onStartScan: () -> Unit,
    onDeviceClick: (BluetoothDevice) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        shape = RoundedCornerShape(16.dp)
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Header with Stop Scan button
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Paired Devices",
                        style = MaterialTheme.typography.titleLarge
                    )

                }
            }

            // Paired Devices Section
            if (state.pairedDevices.isNotEmpty()) {
                item {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(3),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.height(200.dp) // Fixed height for grid
                    ) {
                        items(state.pairedDevices) { device ->
                            BluetoothDeviceCard(
                                device = device,
                                iconResId = R.drawable.triangleguard,
                                onClick = onDeviceClick
                            )
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }

            // Scanned Devices Section
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ){
                    Row(){
                        Text(
                            text = "Scanned Devices",
                            style = MaterialTheme.typography.titleLarge,
                            modifier = Modifier.padding(bottom = 16.dp)
                        )

                        //Loader for scanning
                        if(state.isScanning){
                            CircularProgressIndicator(
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }


                    //Toggle button for scanning

                    Text(
                        text = if(state.isScanning) "Stop Scan" else "Start Scan",
                        modifier = Modifier.clickable{
                            if(state.isScanning){
                                onStopScan()
                            }else{
                                onStartScan()
                            }
                        },
                        style = TextStyle(color = Pink40)


                    )

                }

            }

            items(state.scannedDevices) { device ->
                BluetoothDeviceCard(
                    device = device,
                    iconResId = R.drawable.circleguard,
                    onClick = onDeviceClick,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}