package com.team23.mdpremotecontroller.ui.bluetooth

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.team23.mdpremotecontroller.R
import com.team23.mdpremotecontroller.ui.components.SquidButton


@Composable
fun LandingScreen(
    onStartScan: () -> Unit,
    onStartServer: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = Modifier
            .padding(24.dp)
            .width(480.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Image(
            painter = painterResource(id = R.drawable.logowhite),
            contentDescription = "SquidCar Logo",
            modifier = Modifier.size(500.dp)
        )

        SquidButton(
            text = "Connect",
            onClick = onStartScan
        )

        SquidButton(
            text = "Start Server",
            onClick = onStartServer
        )
    }
}