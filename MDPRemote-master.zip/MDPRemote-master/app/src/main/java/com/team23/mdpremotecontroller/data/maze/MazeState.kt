package com.team23.mdpremotecontroller.data.maze

data class MazeState(
    val obstacles: List<Obstacle> = emptyList(),
    val selectedObstacleId: Int? = null,
    val isDragMode: Boolean = false,
    val robot: RobotState? = null
) {
    fun addObstacle(obstacle: Obstacle): MazeState {
        return if (isPositionEmpty(obstacle.coordinate)) {
            copy(obstacles = obstacles + obstacle)
        } else {
            this
        }
    }

    fun removeObstacle(id: Int): MazeState {
        return copy(obstacles = obstacles.filterNot { it.id == id })
    }

    fun updateObstacle(id: Int, newCoordinate: Coordinate): MazeState {
        return if (isPositionEmpty(newCoordinate)) {
            copy(
                obstacles = obstacles.map {
                    if (it.id == id) it.copy(coordinate = newCoordinate) else it
                }
            )
        } else {
            this
        }
    }

    fun rotateObstacle(id: Int): MazeState {

        return copy(
            obstacles = obstacles.map {
                if (it.id == id) it.copy(hasDirection = true, direction = it.direction.rotate()) else it
            }
        )
    }

    fun rotateObstacle(id: Int, direction: Direction): MazeState {
        return copy(
            obstacles = obstacles.map {
                if (it.id == id) it.copy(direction = direction) else it
            }
        )
    }

    fun rotateRobot(): MazeState{
        return copy(
            robot = robot?.rotate(robot.direction.rotate())
        )
    }

    private fun isPositionEmpty(coordinate: Coordinate): Boolean {
        return obstacles.none { it.coordinate == coordinate }
    }

    fun updateTarget(obstacleNumber: Int, targetId: Int): MazeState {
        return copy(
            obstacles = obstacles.map {
                if (it.id == obstacleNumber) it.copy(targetId = targetId) else it
            }
        )
    }
}
