package com.team23.mdpremotecontroller.ui.theme

import androidx.compose.ui.graphics.Color

// Dark theme colors
val Pink80 = Color(0xFFFF69B4)  // Squid Game pink
val Teal80 = Color(0xFF40E0D0)  // Squid Game worker uniform
val Gray80 = Color(0xFF656565)  // Guard mask color

// Light theme colors
val Pink40 = Color(0xFFFF1493)  // Deeper Squid Game pink
val Teal40 = Color(0xFF008B8B)  // Darker teal
val Gray40 = Color(0xFF363636)  // Darker guard mask

val LightGray = Color(0xFFE3E3E3)
val LightTeal = Color(0xFF40E0D0) //Light Teal