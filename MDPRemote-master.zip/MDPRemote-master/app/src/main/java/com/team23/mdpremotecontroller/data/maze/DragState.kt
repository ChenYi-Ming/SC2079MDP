package com.team23.mdpremotecontroller.data.maze

import kotlinx.coroutines.flow.MutableStateFlow

sealed class DragState {
    data class DraggingObstacle(
        val obstacle: Obstacle,
        val isNew: Boolean = false
    ) : DragState()


    data class DraggingRobot(
        val robotState: RobotState
    ) : DragState()


}