package com.team23.mdpremotecontroller.ui.message

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.team23.mdpremotecontroller.data.maze.RobotState
import com.team23.mdpremotecontroller.data.message.BluetoothMessage
import com.team23.mdpremotecontroller.data.message.MessageType
import com.team23.mdpremotecontroller.data.message.RobotCommand
import com.team23.mdpremotecontroller.data.message.getDirection
import com.team23.mdpremotecontroller.data.message.getInt
import com.team23.mdpremotecontroller.data.message.getString
import com.team23.mdpremotecontroller.data.message.validateMetadata
import com.team23.mdpremotecontroller.ui.theme.LightTeal
import com.team23.mdpremotecontroller.ui.theme.MDPRemoteControllerTheme
import com.team23.mdpremotecontroller.ui.theme.Pink40
import com.team23.mdpremotecontroller.ui.theme.Teal40


@Composable
fun ChatMessage(
    message: BluetoothMessage,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(
                RoundedCornerShape(
                    topStart = if (message.isFromLocalUser) 15.dp else 0.dp,
                    topEnd = 15.dp,
                    bottomStart = 15.dp,
                    bottomEnd = if (message.isFromLocalUser) 0.dp else 15.dp
                )
            )
            .background(
                //If the message from the local user we use the teal color, otherwise the pink(for the machine)
                if (message.isFromLocalUser) LightTeal else Color.White
            )
            .padding(16.dp)
    ) {
        Text(
            text = message.type.toString(),
            fontSize = 10.sp,
            color = Color.Black
        )
        var textMessage = ""

        //Validate
        if(!message.validateMetadata()){
            Text(
                text = "Error processing: $message",
                color = Color.Red
            )
            return
        }

        //Handle the text message based on message type
        when (message.type) {
            MessageType.STATUS_UPDATE -> {
                textMessage = message.metadata["status"].toString()
            }
            MessageType.ROBOT_MOVEMENT -> {
                //Convert the code to proper text
                textMessage = when (message.metadata["direction"]) {
                    RobotCommand.FORWARD.code -> "Move Forward"
                    RobotCommand.REVERSE.code -> "Move Backward"
                    RobotCommand.FORWARD_LEFT.code -> "Move Forward Left"
                    RobotCommand.FORWARD_RIGHT.code -> "Move Forward Right"
                    else -> "Unknown"
                }

            }
            MessageType.ROBOT_POSITION -> {

                textMessage = "Move Robot to ${message.metadata["x"]}, ${message.metadata["y"]}"
                val direction = message.getDirection("direction")
                if(direction != null){
                    textMessage += " facing $direction"
                }

            }
            MessageType.TARGET_UPDATE -> {

                //obstacle number and target id
                textMessage = "Obstacle ${message.metadata["obstacleNumber"]} found target ${message.metadata["targetId"]}"


            }
            MessageType.OBSTACLE_UPDATE -> {
                //x, y, number, direction
                val x = message.getInt("x")
                val y = message.getInt("y")
                val number = message.getInt("number")
                val direction = message.getDirection("direction")

                textMessage = "ID: $number at $x, $y"
                if(direction != null){
                    textMessage += " facing $direction"
                }
            }
            MessageType.TARGET_FACE -> {
                textMessage = "Found Target on Obstacle ${message.metadata["obstacleNumber"]} to be facing ${message.metadata["side"]}"
            }
            MessageType.TEXT_MESSAGE -> {
                textMessage = message.message
            }
            MessageType.COMMAND -> {
                //beginExplore: Start Exploring Algorithm
                //beginFastest: Start Fastest Algorithm
                //sendArena: Request Arena Information
                when (message.metadata["command"]) {
                    RobotCommand.BEGIN_EXPLORE.code -> textMessage = "Begin Exploring Algorithm"
                    RobotCommand.BEGIN_FASTEST.code -> textMessage = "Begin Fastest Algorithm"
                    RobotCommand.SEND_ARENA.code -> textMessage = "Request Arena Information"
                    else->{
                        textMessage = message.getString("command")?: "Unknown Command"
                    }
                }
            }
        }

        Text(
            text = textMessage,
            color = Color.Black,
            modifier = Modifier.widthIn(max = 250.dp)
        )
    }
}

@Preview
@Composable
fun ChatMessagePreview() {
    MDPRemoteControllerTheme {
        ChatMessage(
            message = BluetoothMessage(
                message = "Hello World!",
                senderName = "Robot",
                isFromLocalUser = true
            )
        )
    }
}