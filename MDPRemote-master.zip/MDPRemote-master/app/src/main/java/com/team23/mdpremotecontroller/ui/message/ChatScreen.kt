package com.team23.mdpremotecontroller.ui.message

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.unit.dp
import com.team23.mdpremotecontroller.data.bluetooth.BluetoothUiState
import com.team23.mdpremotecontroller.data.message.MessageType
import com.team23.mdpremotecontroller.ui.theme.Pink40
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MessageTypeFilter(
    selectedTypes: Set<MessageType>,
    onTypeSelected: (MessageType) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Row(
        modifier = modifier
            .horizontalScroll(scrollState)
            .padding(horizontal = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        MessageType.entries.forEach { type ->
            FilterChip(
                selected = type in selectedTypes,
                onClick = { onTypeSelected(type) },
                label = { Text(getMessageTypeLabel(type)) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = Pink40,
                    selectedLabelColor = Color.White
                )
            )
        }
    }
}

fun getMessageTypeLabel(type: MessageType): String {
    return when (type) {
        MessageType.STATUS_UPDATE -> "Status"
        MessageType.ROBOT_MOVEMENT -> "Movement"
        MessageType.ROBOT_POSITION -> "Position"
        MessageType.TARGET_UPDATE -> "Target"
        MessageType.OBSTACLE_UPDATE -> "Obstacle"
        MessageType.TARGET_FACE -> "Face"
        MessageType.TEXT_MESSAGE -> "Message"
        MessageType.COMMAND -> "Command"
    }
}

@Composable
fun ChatScreen(
    state: BluetoothUiState,
    onDisconnect: () -> Unit,
    onSendMessage: (String) -> Unit
) {
    var selectedTypes by remember { mutableStateOf(setOf<MessageType>()) }
    val message = rememberSaveable { mutableStateOf("") }
    val keyboardController = LocalSoftwareKeyboardController.current
    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()

    // Filter messages based on selected types
    val filteredMessages = if (selectedTypes.isEmpty()) {
        state.messages
    } else {
        state.messages.filter { it.type in selectedTypes }
    }

    // Auto-scroll to bottom when new messages arrive
    LaunchedEffect(filteredMessages.size) {
        if (filteredMessages.isNotEmpty()) {
            listState.animateScrollToItem(filteredMessages.size - 1)
        }
    }

    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Messages",
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = onDisconnect) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Disconnect"
                )
            }
        }

        // Filter chips
        MessageTypeFilter(
            selectedTypes = selectedTypes,
            onTypeSelected = { type ->
                selectedTypes = if (type in selectedTypes) {
                    selectedTypes - type
                } else {
                    selectedTypes + type
                }
            },
            modifier = Modifier.fillMaxWidth()
        )

        // Messages list
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(filteredMessages) { message ->
                Column(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    ChatMessage(
                        message = message,
                        modifier = Modifier.align(
                            if(message.isFromLocalUser) Alignment.End else Alignment.Start
                        )
                    )
                }
            }
        }

        // Message input
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextField(
                value = message.value,
                onValueChange = { message.value = it },
                modifier = Modifier.weight(1f),
                placeholder = {
                    Text(text = "Message")
                }
            )
            IconButton(
                onClick = {
                    if (message.value.isNotEmpty()) {
                        onSendMessage(message.value)
                        message.value = ""
                        keyboardController?.hide()
                        coroutineScope.launch {
                            listState.animateScrollToItem(filteredMessages.size)
                        }
                    }
                }
            ) {
                Icon(
                    imageVector = Icons.Default.Send,
                    contentDescription = "Send message"
                )
            }
        }
    }
}