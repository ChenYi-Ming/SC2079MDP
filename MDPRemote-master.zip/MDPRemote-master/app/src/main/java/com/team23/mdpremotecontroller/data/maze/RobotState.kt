package com.team23.mdpremotecontroller.data.maze

data class RobotState(
    val coordinate: Coordinate,
    val direction: Direction,
    val status: RobotStatus = RobotStatus.IDLE,
    val path: List<Coordinate> = emptyList()
) {

    companion object{
        const val SIZE = 3
    }

    fun move(newCoordinate: Coordinate): RobotState {
        return copy(
            coordinate = newCoordinate,
            path = path + newCoordinate
        )
    }

    fun rotate(newDirection: Direction): RobotState {
        return copy(direction = newDirection)
    }

    fun updateStatus(newStatus: RobotStatus): RobotState {
        return copy(status = newStatus)
    }

    fun clearPath(): RobotState {
        return copy(path = emptyList())
    }
}