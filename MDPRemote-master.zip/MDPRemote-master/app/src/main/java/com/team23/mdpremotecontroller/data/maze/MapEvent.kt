package com.team23.mdpremotecontroller.data.maze


sealed class MapEvent {
    // Robot Events
    data class MoveRobot(val x: Int, val y: Int) : MapEvent()
    data class RotateRobot(val direction: Direction) : MapEvent()
    data class MoveRobotForward(val distance: Int = 1) : MapEvent()
    data class MoveRobotBackward(val distance: Int = 1) : MapEvent()
    object TurnRobotLeft : MapEvent()
    object TurnRobotRight : MapEvent()

    //Map events
    object ClearMap : MapEvent()

    //Obstacle events
    data class PlaceObstacle(val obstacleId: Int, val x: Int, val y: Int) : MapEvent()
    data class MoveObstacle(val obstacleId: Int, val x: Int, val y: Int) : MapEvent()
    data class RotateObstacle(val obstacleId: Int) : MapEvent()
    data class RemoveObstacle(val obstacleId: Int) : MapEvent()
    data class SetObstacleTarget(val obstacleId: Int, val targetId: Int) : MapEvent()
}