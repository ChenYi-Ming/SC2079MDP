package com.team23.mdpremotecontroller.data.bluetooth

import java.io.IOException

class TransferFailedException : IOException("Reading incoming data")
