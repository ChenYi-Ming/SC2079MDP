package com.team23.mdpremotecontroller.data.message

enum class RobotCommand(val code: String) {
    FORWARD("f"),
    REVERSE("r"),
    FORWARD_LEFT("fl"),
    FORWARD_RIGHT("fr"),
    BACKWARD_LEFT("bl"),
    BACKWARD_RIGHT("br"),
    BEGIN_EXPLORE("beginExplore"),
    BEGIN_FASTEST("beginFastest"),
    SEND_ARENA("sendArena")
}