package com.team23.mdpremotecontroller.data.maze

import org.json.JSONArray
import org.json.JSONObject

/**
 * Extension function to convert MazeState to a JSON string representation.
 * This serializes the entire grid state including obstacles and robot position.
 * Direction values are stored as strings (NORTH, SOUTH, EAST, WEST) for better readability
 * and consistency with the rest of the application.
 */
fun MazeState.toJsonString(): String {
    val jsonObject = JSONObject()

    // Convert obstacles to JSON array
    val obstaclesArray = JSONArray()
    obstacles.forEach { obstacle ->
        val obstacleJson = JSONObject().apply {
            put("x", obstacle.coordinate.x)
            put("y", obstacle.coordinate.y)
            put("id", obstacle.id)
            // Store direction as a string value
            put("d", obstacle.direction.name)
        }
        obstaclesArray.put(obstacleJson)
    }
    jsonObject.put("obstacles", obstaclesArray)

    // Add robot state if present
    robot?.let { robot ->
        jsonObject.put("robot_x", robot.coordinate.x)
        jsonObject.put("robot_y", robot.coordinate.y)
        jsonObject.put("robot_dir", robot.direction.name)
    }

    return jsonObject.toString()
}

/**
 * Extension function to parse a JSON string back into a MazeState.
 * This deserializes the grid state from JSON, expecting direction values
 * to be string representations of Direction enum values.
 */
fun String.toMazeState(): MazeState {
    val jsonObject = JSONObject(this)
    val obstacles = mutableListOf<Obstacle>()

    // Parse obstacles array
    val obstaclesArray = jsonObject.getJSONArray("obstacles")
    for (i in 0 until obstaclesArray.length()) {
        val obstacleJson = obstaclesArray.getJSONObject(i)
        val direction = Direction.valueOf(obstacleJson.getString("d"))

        obstacles.add(Obstacle(
            id = obstacleJson.getInt("id"),
            coordinate = Coordinate(
                x = obstacleJson.getInt("x"),
                y = obstacleJson.getInt("y")
            ),
            direction = direction
        ))
    }

    // Parse robot state if present
    val robotState = if (jsonObject.has("robot_x")) {
        RobotState(
            coordinate = Coordinate(
                x = jsonObject.getInt("robot_x"),
                y = jsonObject.getInt("robot_y")
            ),
            direction = Direction.valueOf(jsonObject.getString("robot_dir"))
        )
    } else null

    return MazeState(
        obstacles = obstacles,
        robot = robotState
    )
}