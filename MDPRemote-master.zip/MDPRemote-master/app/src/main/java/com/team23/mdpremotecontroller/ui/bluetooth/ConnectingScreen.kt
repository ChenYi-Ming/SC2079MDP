package com.team23.mdpremotecontroller.ui.bluetooth
import androidx.compose.foundation.Image

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.team23.mdpremotecontroller.R
import com.team23.mdpremotecontroller.ui.components.SquidButton

@Composable
fun ConnectingScreen(
    onCancel: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.padding(16.dp),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .padding(24.dp)
                .width(280.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.circleguard),
                contentDescription = "Connecting",
                modifier = Modifier.size(120.dp)
            )

            Text(
                text = "Connecting to Device...",
                style = MaterialTheme.typography.titleLarge
            )

            CircularProgressIndicator(
                modifier = Modifier.size(48.dp),
                color = MaterialTheme.colorScheme.primary
            )

            SquidButton(
                text = "Cancel",
                onClick = onCancel
            )
        }
    }
}