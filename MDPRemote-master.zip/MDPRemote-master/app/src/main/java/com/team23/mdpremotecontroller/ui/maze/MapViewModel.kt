package com.team23.mdpremotecontroller.ui.maze

import android.content.Context
import android.content.SharedPreferences
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.team23.mdpremotecontroller.data.bluetooth.BluetoothController
import com.team23.mdpremotecontroller.data.maze.Coordinate
import com.team23.mdpremotecontroller.data.maze.Direction
import com.team23.mdpremotecontroller.data.maze.DragState
import com.team23.mdpremotecontroller.data.maze.MapEvent
import com.team23.mdpremotecontroller.data.maze.MazeState
import com.team23.mdpremotecontroller.data.maze.Obstacle
import com.team23.mdpremotecontroller.data.maze.PlaceState
import com.team23.mdpremotecontroller.data.maze.RobotState
import com.team23.mdpremotecontroller.data.maze.RobotStatus
import com.team23.mdpremotecontroller.data.maze.toJsonString
import com.team23.mdpremotecontroller.data.maze.toMazeState
import com.team23.mdpremotecontroller.data.message.BluetoothMessage
import com.team23.mdpremotecontroller.data.message.MessageType
import com.team23.mdpremotecontroller.data.message.RobotCommand
import com.team23.mdpremotecontroller.data.message.getDirection
import com.team23.mdpremotecontroller.data.message.getInt
import com.team23.mdpremotecontroller.data.message.toMessageString
import com.team23.mdpremotecontroller.data.message.validateMetadata
import com.team23.mdpremotecontroller.ui.bluetooth.BluetoothViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class MapViewModel @Inject constructor(
    private val bluetoothViewModel: BluetoothViewModel,
    @ApplicationContext private val context: Context
) : ViewModel() {
    private val _mazeState = MutableStateFlow(
        MazeState(

        )
    )
    val mazeState: StateFlow<MazeState> = _mazeState.asStateFlow()

    private val _isDragging = MutableStateFlow<DragState?>(null)
    val isDragging: StateFlow<DragState?> = _isDragging.asStateFlow()

    private val _placeState = MutableStateFlow(PlaceState.None)
    val placeState: StateFlow<PlaceState> = _placeState.asStateFlow()

    private var nextObstacleId = 1

    private val prefs: SharedPreferences = context.getSharedPreferences(
        "maze_prefs", Context.MODE_PRIVATE
    )

    init {
        viewModelScope.launch {
            bluetoothViewModel.messages.collect { message ->
                handleMessage(message)
            }
        }
    }


    private fun handleMessage(bluetoothMessage: BluetoothMessage) {
        // Validate metadata first
        if (!bluetoothMessage.validateMetadata()) {
            println("Invalid metadata for message: $bluetoothMessage")
            return
        }

       when(bluetoothMessage.type){
           MessageType.STATUS_UPDATE -> {
               //Not our problem, this is for the MovementViewModel
           }
           MessageType.ROBOT_MOVEMENT -> {
               //Map the message
               val direction = bluetoothMessage.metadata["direction"]!!

               println("ROBOT ORDERED TO MOVE $direction")
               //Convert to Robot Command
               when(direction){
                   RobotCommand.FORWARD.code ->{
                       moveRobotForward(1)
                   }
                   RobotCommand.REVERSE.code -> moveRobotBackward(1)
                   RobotCommand.FORWARD_LEFT.code ->{
                       moveRobotForward(1)
                       turnRobotLeft()
                       moveRobotForward(1)
                   }
                   RobotCommand.FORWARD_RIGHT.code ->{
                       moveRobotForward(1)
                       turnRobotRight()
                       moveRobotForward(1)
                   }

                   RobotCommand.BACKWARD_LEFT.code ->{
                       moveRobotBackward(1)
                       turnRobotRight()
                       moveRobotBackward(1)
                   }
                   RobotCommand.BACKWARD_RIGHT.code ->{
                       moveRobotBackward(1)
                       turnRobotLeft()
                       moveRobotBackward(1)
                   }
               }


           }
           MessageType.ROBOT_POSITION -> {
               //We already updated our position here
               if(bluetoothMessage.isFromLocalUser) return

               //map the message
               val robot = RobotState(
                   coordinate = Coordinate(bluetoothMessage.getInt("x")!!, bluetoothMessage.metadata["y"]!!.toInt()),
                   direction = Direction.valueOf(bluetoothMessage.getDirection("direction").toString())
               )

               _mazeState.update { it.copy(robot = robot) }
           }
           MessageType.TARGET_UPDATE -> {
               //Get the target information
               val targetId = bluetoothMessage.getInt("targetId")!!
               val obstacleNumber = bluetoothMessage.getInt("obstacleNumber")!!
               //Change the target value
               _mazeState.update { it.updateTarget(obstacleNumber, targetId) }

           }
           MessageType.OBSTACLE_UPDATE -> {


           }
           MessageType.TARGET_FACE -> {
               val obstacleNumber = bluetoothMessage.getInt("obstacleNumber")!!
               val side = bluetoothMessage.getDirection("side")!!



               _mazeState.update { it.rotateObstacle(obstacleNumber, side) }

           }
           MessageType.TEXT_MESSAGE -> {
               //Not my problem
           }
           MessageType.COMMAND -> {
               when (bluetoothMessage.metadata["command"]) {
                   "clearMap" -> resetMap()

                   else -> println("Unknown command: ${bluetoothMessage.metadata["command"]}")

               }
           }
       }

    }

    /*
    * Handle the Deploy Buttons
    * */
    fun selectPlacementButton(placeState: PlaceState){

        //Toggle
        if(_placeState.value == placeState){
            _placeState.update { PlaceState.None }
            return
        }
        _placeState.update { placeState }

    }

    fun onDragStart(coordinate: Coordinate){
        //Check what's on it
        val obstacle = _mazeState.value.obstacles.find { it.coordinate == coordinate }
        //If there's an obstacle, handle it
        if(obstacle != null){
            //Set the dragging state
            _isDragging.update { DragState.DraggingObstacle(obstacle) }
            println("Dragging obstacle!")
            return
        }
        //Check if robot (if selecting within its size area)
        val robotCoordinate = _mazeState.value.robot?.coordinate
        println("Robot coordinate: $robotCoordinate, our coordinate is $coordinate")
        if(robotCoordinate != null){
            val (x, y) = robotCoordinate
            if(coordinate.x in x until x + RobotState.SIZE && coordinate.y in y until y + RobotState.SIZE){
                _isDragging.update { DragState.DraggingRobot(_mazeState.value.robot!!) }
                println("Dragging robot!")
                return
            }
        }

        //Nothing
        _isDragging.update { null }
        println("Nothing ever happens")


    }

    fun onDrag(coordinate: Coordinate){
        //If the drag state is null, return
        val dragState = _isDragging.value ?: return

        when(dragState){
            is DragState.DraggingObstacle -> {
                moveObstacle(dragState.obstacle.id, coordinate)
            }
            is DragState.DraggingRobot -> {
                moveRobot(clampCoordinatesToGrid(coordinate))
            }

        }


    }

    fun onDragEnd(){
        //Check what was being done
        val dragState = _isDragging.value ?: return


        notifyBluetooth(dragState)

        _isDragging.update { null }
    }

    private fun notifyBluetooth(robotState: RobotState){
        val  message = BluetoothMessage.createRobotPosition(robotState, "Remote").toMessageString()
        viewModelScope.launch {
            bluetoothViewModel.sendMessage(message)

        }
    }

    private fun notifyBluetooth(obstacle: Obstacle){
        val message = BluetoothMessage.createObstacleUpdate(obstacle, "Remote").toMessageString()
        viewModelScope.launch {
            bluetoothViewModel.sendMessage(message)

        }
    }

    private fun notifyBluetooth(dragState: DragState){

        val message = when(dragState){
            is DragState.DraggingObstacle -> {
                BluetoothMessage.createObstacleUpdate(dragState.obstacle, "Remote").toMessageString()

            }

            is DragState.DraggingRobot ->{
                BluetoothMessage.createRobotPosition(dragState.robotState, "Remote").toMessageString()

            }
        }

        viewModelScope.launch {
            bluetoothViewModel.sendMessage(message)

        }

    }

    fun onLongPress(coordinate: Coordinate){
        //Check what's on it
        val obstacle = _mazeState.value.obstacles.find { it.coordinate == coordinate }
        //If there's an obstacle, handle it
        if(obstacle != null){
            //Delete
            removeObstacle(obstacle.id)
            return
        }

        //Delete robot
        if(_mazeState.value.robot?.coordinate == coordinate){
            _mazeState.update { it.copy(robot = null) }
            return
        }
    }

    fun onTap(coordinate: Coordinate){
        //Check if placestate is not none
        if(_placeState.value != PlaceState.None){
            //Handle the placement
            if(_placeState.value == PlaceState.Obstacle){
                placeObstacle(nextObstacleId++, coordinate)
            }else if(_placeState.value == PlaceState.Car){
                placeRobot(coordinate, Direction.NORTH)
            }


            return
        }


        //Check what's on it
        val obstacle = _mazeState.value.obstacles.find { it.coordinate == coordinate }
        //If there's an obstacle, handle it
        if(obstacle != null){
            //Rotate
            rotateObstacle(obstacle.id)
            return
        }

        //Check if it is the robot
        val robotCoordinate = _mazeState.value.robot?.coordinate
        if(robotCoordinate != null){
            val (x, y) = robotCoordinate
            if(coordinate.x in x until x + RobotState.SIZE && coordinate.y in y until y + RobotState.SIZE){
                //Rotate
                rotateRobot()
                return
            }
        }


    }

    //Handle map state changes

    fun resetMap(){
        _mazeState.update { MazeState() }
        nextObstacleId = 1
        _placeState.update { PlaceState.None }
        _isDragging.update { null }
        println("Map reset")
        //Send reset command
        bluetoothViewModel.sendMessage("CMD,resetMap")

    }

    fun saveMap(){
        //Save it in persistent storage
        prefs.edit().putString("saved_maze", _mazeState.value.toJsonString()).apply()
        println("Map saved")
        //Send the maze state
        sendMazeState()
    }

    fun loadMap(){
        //Load it from persistent storage
        val savedMaze = prefs.getString("saved_maze", null)
        if(savedMaze != null){
            _mazeState.update { savedMaze.toMazeState() }
            println("Map loaded")
        }
        sendMazeState()
    }

    private fun placeObstacle(id: Int, coordinate: Coordinate){
        println("Placing obstacle $id at $coordinate.x, $coordinate.y")
        if(!isValidPosition(coordinate)){
            println("Invalid position")
            //Deselect
            _mazeState.update { it.copy(selectedObstacleId = null) }
            return
        }


        val obstacle = Obstacle(id, coordinate, Direction.NORTH)
        _mazeState.update { it.addObstacle(obstacle) }

        notifyBluetooth(obstacle)

    }

    private fun moveObstacle(id: Int, coordinate: Coordinate){
        println("Moving obstacle $id to $coordinate.x, $coordinate.y")

        if(!isValidPosition(coordinate)) {
            println("Invalid position")
            //Deselect
            _mazeState.update { it.copy(selectedObstacleId = null) }
            //If the obstacle is being moved, remove it
            removeObstacle(id)
            return
        }
        _mazeState.update { it.updateObstacle(id, coordinate) }

    }

    private fun rotateObstacle(id: Int){
        println("Rotating obstacle $id")
        _mazeState.update { it.rotateObstacle(id) }
        //Notify bluetooth
        notifyBluetooth(_mazeState.value.obstacles.find { it.id == id }!!)
    }

    private fun removeObstacle(id: Int) {
        println("Removing obstacle $id")
        _mazeState.update { it.removeObstacle(id) }
    }

    private fun placeRobot(coordinate: Coordinate, direction: Direction){
        println("Placing robot at $coordinate.x, $coordinate.y with direction $direction")

        //Check if the robot is valid
        if(!isValidRobotPosition(coordinate)){
            println("Invalid position")
            return
        }

        val robot = RobotState(coordinate, direction)
        _mazeState.update { it.copy(robot = robot) }
        notifyBluetooth(robot)

    }

    private fun moveRobot(coordinate: Coordinate){


        //Check if the robot is valid
        if(!isValidRobotPosition(coordinate)){
            println("Invalid position at $coordinate")
            return
        }
        println("Moving robot to position $coordinate.x, $coordinate.y")
        _mazeState.update { it.copy(robot = _mazeState.value.robot?.move(coordinate)) }

    }


    private fun rotateRobot(){
        println("Rotating robot")
        _mazeState.update { it.copy(robot = _mazeState.value.robot?.rotate(_mazeState.value.robot!!.direction.rotate())) }
        notifyBluetooth(_mazeState.value.robot!!)
    }

    private fun setRobotRotation(direction: Direction){
        println("Setting robot rotation")
        _mazeState.update { it.copy(robot = _mazeState.value.robot?.rotate(direction)) }
    }

    private fun moveRobotForward(distance: Int) {
        mazeState.value.robot?.let { robot ->
            val (newX, newY) = when (robot.direction) {
                Direction.NORTH -> robot.coordinate.x to robot.coordinate.y + distance
                Direction.SOUTH -> robot.coordinate.x to robot.coordinate.y - distance
                Direction.EAST -> robot.coordinate.x + distance to robot.coordinate.y
                Direction.WEST -> robot.coordinate.x - distance to robot.coordinate.y
            }
            moveRobot(Coordinate(newX, newY))
        }
    }

    private fun moveRobotBackward(distance: Int) {
        moveRobotForward(-distance)
    }

    private fun turnRobotLeft() {
        _mazeState.value.robot?.let { robot ->
            val newDirection = when (robot.direction) {
                Direction.NORTH -> Direction.WEST
                Direction.WEST -> Direction.SOUTH
                Direction.SOUTH -> Direction.EAST
                Direction.EAST -> Direction.NORTH
            }
            setRobotRotation(newDirection)
        }
    }

    private fun turnRobotRight() {
        _mazeState.value.robot?.let { robot ->
            val newDirection = when (robot.direction) {
                Direction.NORTH -> Direction.EAST
                Direction.EAST -> Direction.SOUTH
                Direction.SOUTH -> Direction.WEST
                Direction.WEST -> Direction.NORTH
            }
            setRobotRotation(newDirection)
        }
    }


    private fun isValidRobotPosition(coordinate: Coordinate): Boolean{
        println("Checking if robot is valid at $coordinate.x, $coordinate.y")
        if(coordinate.x <1 || coordinate.x+ 1 >= Obstacle.GRID_SIZE
            || coordinate.y < 1 || coordinate.y+1 >= Obstacle.GRID_SIZE)
        {
            println("Invalid position")
            return false
        }

        return _mazeState.value.obstacles.none { it.coordinate == coordinate }

    }

    private fun sendMazeState(){
        viewModelScope.launch {
            val mazeState = _mazeState.value
            bluetoothViewModel.sendMessage("CMD,sendArena,${mazeState.toJsonString()}")
        }
    }


    private fun isValidPosition(coord: Coordinate): Boolean {
        return coord.x in 0 until Obstacle.GRID_SIZE && coord.y in 0 until Obstacle.GRID_SIZE
    }

    private fun clampCoordinatesToGrid(coordinate: Coordinate): Coordinate{
        return Coordinate(
            x = coordinate.x.coerceIn(0, Obstacle.GRID_SIZE - 1),
            y = coordinate.y.coerceIn(0, Obstacle.GRID_SIZE - 1)
        )
    }

}