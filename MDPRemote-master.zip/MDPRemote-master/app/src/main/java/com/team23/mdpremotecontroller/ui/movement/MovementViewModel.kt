package com.team23.mdpremotecontroller.ui.movement

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.team23.mdpremotecontroller.data.bluetooth.BluetoothController
import com.team23.mdpremotecontroller.data.message.BluetoothMessage
import com.team23.mdpremotecontroller.data.message.MessageType
import com.team23.mdpremotecontroller.data.message.RobotCommand
import com.team23.mdpremotecontroller.data.message.validateMetadata
import com.team23.mdpremotecontroller.ui.bluetooth.BluetoothViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject
import java.text.SimpleDateFormat
import java.util.*

data class MovementUiState(
    val currentCommand: RobotCommand? = null,
    val isActionRunning: Boolean = false,
    val elapsedTime: Long = 0L,
    val finalElapsedTime: Long? = null,
    val currentAction: String? = null,
    val currentStatus: String = "Ready"
)

@HiltViewModel
class MovementViewModel @Inject constructor(
    private val bluetoothViewModel: BluetoothViewModel
): ViewModel() {

    private val _uiState = MutableStateFlow(MovementUiState())
    val uiState = _uiState.asStateFlow()


    private var timerJob: Job? = null

    init {
        // Listen for Bluetooth messages
        viewModelScope.launch {
            bluetoothViewModel.messages.collect { message ->
                processMessage(message)
            }
        }
    }

    private fun processMessage(message: BluetoothMessage) {
        //Validate message
        if (!message.validateMetadata()) {
            println("Invalid metadata for message: $message")
            return
        }

        println("Received message ${message.type} with metadata: ${message.metadata}")


        when (message.type) {
            MessageType.STATUS_UPDATE -> {
                // Extract status from message metadata
                message.metadata["status"]?.let { status ->
                    updateStatus(status)
                }
            }
            else -> {} // Handle other message types if needed
        }
    }

    private fun updateStatus(newStatus: String) {
        _uiState.update { currentState ->
            currentState.copy(
                currentStatus = newStatus
            )
        }
    }

    fun sendMovementCommand(command: RobotCommand) {
        viewModelScope.launch {
            _uiState.update { it.copy(currentCommand = command) }
            bluetoothViewModel.sendMessage("MOVE,${command.code}")
            delay(100) // Reset state after brief delay
            _uiState.update { it.copy(currentCommand = null) }
        }
    }

    fun startAction(action: String) {
        // Cancel any existing timer
        timerJob?.cancel()

        // Start new timer
        timerJob = viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isActionRunning = true,
                    elapsedTime = 0L,
                    currentAction = action
                )
            }

            val startTime = System.currentTimeMillis()
            while (true) {
                delay(100) // Update every 100ms
                val currentTime = System.currentTimeMillis()
                _uiState.update {
                    it.copy(elapsedTime = currentTime - startTime)
                }
            }
        }

        // Send the appropriate command
        when (action) {
            "Explore" -> sendCustomCommand(RobotCommand.BEGIN_EXPLORE.code)
            "Fastest" -> sendCustomCommand(RobotCommand.BEGIN_FASTEST.code)
        }
    }

    fun stopAction() {
        timerJob?.cancel()
        val time = _uiState.value.elapsedTime
        _uiState.update {
            it.copy(
                isActionRunning = false,
                currentAction = null,
                finalElapsedTime = time,
                elapsedTime = 0L
            )
        }
    }

    fun formatTime(timeMillis: Long): String {
        val seconds = (timeMillis / 1000) % 60
        val minutes = (timeMillis / (1000 * 60)) % 60
        val milliseconds = (timeMillis % 1000) / 10 // Get only 2 digits
        return String.format("%02d:%02d.%02d", minutes, seconds, milliseconds)
    }

    private fun sendCustomCommand(command: String) {
        viewModelScope.launch {
            bluetoothViewModel.sendMessage("CMD,$command")
        }
    }

    // Helper methods for common commands
    fun startExploration() = startAction("Explore")
    fun startFastestPath() = startAction("Fastest")

    override fun onCleared() {
        super.onCleared()
        timerJob?.cancel()
        viewModelScope.cancel()
    }
}