package com.team23.mdpremotecontroller.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.team23.mdpremotecontroller.data.bluetooth.BluetoothUiState
import com.team23.mdpremotecontroller.ui.message.ChatScreen
import com.team23.mdpremotecontroller.ui.maze.MapGrid
import com.team23.mdpremotecontroller.ui.maze.MapScreen
import com.team23.mdpremotecontroller.ui.maze.MapViewModel
import com.team23.mdpremotecontroller.ui.movement.MovementScreen
import com.team23.mdpremotecontroller.ui.movement.MovementViewModel
import com.team23.mdpremotecontroller.ui.theme.LightGray
import com.team23.mdpremotecontroller.ui.theme.LightTeal
import com.team23.mdpremotecontroller.ui.theme.Pink40
import com.team23.mdpremotecontroller.ui.theme.Teal40

enum class Screen {
    MAZE,
    DRIVE,
    CHAT
}

@Composable
fun MainContent(
    state: BluetoothUiState,
    movementViewModel: MovementViewModel = hiltViewModel(),
    mapViewModel: MapViewModel = hiltViewModel(),
    onDisconnect: () -> Unit,
    onSendMessage: (String) -> Unit
) {
    var selectedTab by remember { mutableStateOf(Screen.MAZE) }



    Box(modifier = Modifier.fillMaxSize().background(Teal40)) {


        // Main content
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .padding(bottom = 80.dp) // Add padding for bottom navigation
        ) {
            when (selectedTab) {
                Screen.MAZE -> {
                    MapScreen(modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                        viewModel = mapViewModel)
                }
                Screen.DRIVE -> {
                    Column(modifier = Modifier.fillMaxSize()) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color.White)
                                .padding(16.dp)
                        ) {
                            MapGrid(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    ,
                                viewModel = mapViewModel
                            )

                        }



                        MovementScreen(
                            state = state,
                            viewModel = movementViewModel,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
                Screen.CHAT -> ChatScreen(
                    state = state,
                    onDisconnect = onDisconnect,
                    onSendMessage = onSendMessage
                )
            }
        }

        // Bottom navigation buttons
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Button(
                onClick = { selectedTab = Screen.MAZE },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (selectedTab == Screen.MAZE) LightTeal else Pink40
                ),
                modifier = Modifier.size(72.dp),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.Build, "Maze")
            }

            Button(
                onClick = { selectedTab = Screen.DRIVE },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (selectedTab == Screen.DRIVE) LightTeal else Pink40
                ),
                modifier = Modifier.size(72.dp),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.PlayArrow, "Drive")
            }

            Button(
                onClick = { selectedTab = Screen.CHAT },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (selectedTab == Screen.CHAT) LightTeal else Pink40
                ),
                modifier = Modifier.size(72.dp),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.Email, "Chat")
            }
        }
        // Disconnect button
        Button(
            onClick = onDisconnect,
            colors = ButtonDefaults.buttonColors(
                containerColor = Pink40
            ),
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(16.dp)
                .background(Teal40, RoundedCornerShape(8.dp))
        ) {
            Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "Disconnect"
            )
        }
    }
}

@Preview
@Composable
fun MainContentPreview(
    state: BluetoothUiState = BluetoothUiState(
        isConnected = true,
        isConnecting = false,
    ), // Provide default values for preview
    onDisconnect: () -> Unit = {},
    onSendMessage: (String) -> Unit = {}
) {
    MainContent(state, onDisconnect = onDisconnect, onSendMessage = onSendMessage)
}