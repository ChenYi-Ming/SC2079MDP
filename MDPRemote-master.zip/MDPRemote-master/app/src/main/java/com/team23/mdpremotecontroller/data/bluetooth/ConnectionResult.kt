package com.team23.mdpremotecontroller.data.bluetooth

import com.team23.mdpremotecontroller.data.message.BluetoothMessage

sealed interface ConnectionResult {
    object ConnectionEstablished: ConnectionResult
    data class TransferSucceeded(val message: BluetoothMessage): ConnectionResult
    data class Error(val message: String): ConnectionResult
}