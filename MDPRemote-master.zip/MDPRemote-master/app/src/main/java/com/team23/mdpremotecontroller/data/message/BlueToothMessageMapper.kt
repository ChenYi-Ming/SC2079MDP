package com.team23.mdpremotecontroller.data.message

import com.team23.mdpremotecontroller.data.maze.Direction
import com.team23.mdpremotecontroller.data.maze.RobotStatus

fun String.toBluetoothMessage(isFromLocalUser: Boolean): BluetoothMessage {
    val name = substringBeforeLast("#")
    val message = substringAfter("#")

    // Parse message type and content
    val type = when {
        message.startsWith("ROBOT,") -> MessageType.ROBOT_POSITION
        message.startsWith("TARGET,") -> MessageType.TARGET_UPDATE
        message.startsWith("STATUS,") -> MessageType.STATUS_UPDATE
        message.startsWith("OBSTACLE,") -> MessageType.OBSTACLE_UPDATE
        message.startsWith("FACE,") -> MessageType.TARGET_FACE
        message.startsWith("MOVE,") -> MessageType.ROBOT_MOVEMENT
        message.startsWith("CMD,") -> MessageType.COMMAND
        else -> MessageType.TEXT_MESSAGE
    }

    // Parse metadata based on message type
    val metadata = when(type) {
        MessageType.ROBOT_POSITION -> {
            val parts = message.split(",")
            mapOf(
                "x" to parts[1],
                "y" to parts[2],
                "direction" to parts[3]
            )
        }
        MessageType.OBSTACLE_UPDATE ->{
            val parts = message.split(",")
            mapOf(
                "x" to parts[1],
                "y" to parts[2],
                "number" to parts[3],
                "direction" to parts[4]
            )
        }



        MessageType.TARGET_UPDATE -> {
            val parts = message.split(",")
            mapOf(
                "obstacleNumber" to parts[1],
                "targetId" to parts[2]
            )
        }
        MessageType.STATUS_UPDATE -> {
            mapOf("status" to message.substringAfter("STATUS,"))
        }

        MessageType.ROBOT_MOVEMENT -> {
            mapOf("direction" to message.substringAfter("MOVE,"))
        }

        MessageType.TARGET_FACE -> {
            //obstacleNumber, side
            val parts = message.split(",")
            mapOf(
                "obstacleNumber" to parts[1],
                "side" to parts[2]
            )
        }

        MessageType.COMMAND -> {
            //command
            mapOf("command" to message.substringAfter("CMD,"))
        }

        MessageType.TEXT_MESSAGE -> emptyMap()
    }

    return BluetoothMessage(
        type = type,
        message = message,
        senderName = name,
        isFromLocalUser = isFromLocalUser,
        metadata = metadata
    )
}


fun BluetoothMessage.toMessageString():String{
    val formattedMessage = when (type) {
        MessageType.ROBOT_POSITION -> "ROBOT,${metadata["x"]},${metadata["y"]},${metadata["direction"]}"
        MessageType.TARGET_UPDATE -> "TARGET,${metadata["obstacleNumber"]},${metadata["targetId"]}"
        MessageType.STATUS_UPDATE -> "STATUS,${metadata["status"]}"
        MessageType.OBSTACLE_UPDATE -> "OBSTACLE,${metadata["x"]},${metadata["y"]},${metadata["number"]},${metadata["direction"]}"
        MessageType.TARGET_FACE -> "FACE,${metadata["obstacleNumber"]},${metadata["side"]}"
        MessageType.ROBOT_MOVEMENT -> "MOVE,${metadata["direction"]}"
        MessageType.COMMAND -> "CMD,${metadata["command"]}"
        MessageType.TEXT_MESSAGE -> message
    }
    return formattedMessage
}

fun BluetoothMessage.validateMetadata(): Boolean {
    return when (type) {
        MessageType.ROBOT_POSITION -> {
            metadata.containsKey("x") &&
                    metadata.containsKey("y") &&
                    metadata.containsKey("direction") &&
                    metadata["x"]?.toIntOrNull() != null &&
                    metadata["y"]?.toIntOrNull() != null &&
                    try {
                        Direction.valueOf(metadata["direction"] ?: "")
                        true
                    } catch (e: IllegalArgumentException) {
                        false
                    }
        }

        MessageType.TARGET_UPDATE -> {
            metadata.containsKey("obstacleNumber") &&
                    metadata.containsKey("targetId") &&
                    metadata["obstacleNumber"]?.toIntOrNull() != null &&
                    metadata["targetId"]?.toIntOrNull() != null
        }

        MessageType.OBSTACLE_UPDATE -> {
            metadata.containsKey("x") &&
                    metadata.containsKey("y") &&
                    metadata.containsKey("number") &&
                    metadata.containsKey("direction") &&
                    metadata["x"]?.toIntOrNull() != null &&
                    metadata["y"]?.toIntOrNull() != null &&
                    metadata["number"]?.toIntOrNull() != null &&
                    try {
                        Direction.valueOf(metadata["direction"] ?: "")
                        true
                    } catch (e: IllegalArgumentException) {
                        false
                    }
        }

        MessageType.TARGET_FACE -> {
            metadata.containsKey("obstacleNumber") &&
                    metadata.containsKey("side") &&
                    metadata["obstacleNumber"]?.toIntOrNull() != null &&
                    try {
                        Direction.valueOf(metadata["side"] ?: "")
                        true
                    } catch (e: IllegalArgumentException) {
                        false
                    }
        }

        MessageType.COMMAND -> {
            metadata.containsKey("command")
        }

        MessageType.ROBOT_MOVEMENT -> {
            metadata.containsKey("direction")
        }

        MessageType.STATUS_UPDATE -> {
            metadata.containsKey("status")
        }

        MessageType.TEXT_MESSAGE -> true // No metadata required
    }
}

fun BluetoothMessage.getInt(key: String): Int? = metadata[key]?.toIntOrNull()
fun BluetoothMessage.getDirection(key: String): Direction? = try {
    metadata[key]?.let { Direction.valueOf(it) }
} catch (e: IllegalArgumentException) {
    null
}
fun BluetoothMessage.getRobotStatus(key: String): RobotStatus? = try {
    metadata[key]?.let { RobotStatus.valueOf(it) }
} catch (e: IllegalArgumentException) {
    null
}

fun BluetoothMessage.getString(key: String): String? = metadata[key]