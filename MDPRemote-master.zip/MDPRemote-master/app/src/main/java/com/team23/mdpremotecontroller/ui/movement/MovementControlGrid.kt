package com.team23.mdpremotecontroller.ui.movement

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun MovementControlGrid(
    onForward: () -> Unit,
    onBackward: () -> Unit,
    onForwardLeft: () -> Unit,
    onForwardRight: () -> Unit,
    onBackwardLeft: () -> Unit,
    onBackwardRight: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Forward row - contains Forward Left, Forward, Forward Right
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MovementButton(onClick = onForwardLeft, text = "↖")
            MovementButton(onClick = onForward, text = "↑")
            MovementButton(onClick = onForwardRight, text = "↗")
        }

        // Center row - empty for spacing
        Box(modifier = Modifier.height(8.dp))

        // Backward row - contains Backward Left, Backward, Backward Right
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MovementButton(onClick = onBackwardLeft, text = "↙")
            MovementButton(onClick = onBackward, text = "↓")
            MovementButton(onClick = onBackwardRight, text = "↘")
        }
    }
}