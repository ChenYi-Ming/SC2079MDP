package com.team23.mdpremotecontroller.ui.bluetooth
/*
 * Adapted from https://github.com/philipplackner/BluetoothChat
 * */
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.team23.mdpremotecontroller.data.bluetooth.BluetoothDevice
import com.team23.mdpremotecontroller.data.bluetooth.BluetoothUiState
import com.team23.mdpremotecontroller.ui.theme.Teal40

/**
 * Main screen for displaying and managing Bluetooth devices.
 * Shows lists of paired and scanned devices with scan controls.
 *
 */
@Composable
fun DeviceScreen(
    state: BluetoothUiState,
    onStartScan: () -> Unit,
    onStopScan: () -> Unit,
    onDeviceClick: (BluetoothDevice) -> Unit,
    onStartServer: () -> Unit,
    onStopServer: () -> Unit,

){
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Teal40)
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        when {
            // Landing Screen
            !state.isConnecting && !state.isConnected && state.scannedDevices.isEmpty() -> {
                LandingScreen(
                    onStartScan = onStartScan,
                    onStartServer = onStartServer
                )
            }
            // Scanning Screen
            !state.isConnecting && !state.isConnected -> {
                ScanningScreen(
                    state = state,
                    onStopScan = onStopScan,
                    onStartScan= onStartScan,
                    onDeviceClick = onDeviceClick
                )
            }
            // Connecting Screen
            state.isConnecting -> {
                ConnectingScreen(
                    onCancel = onStopServer
                )
            }
        }
    }
}

