package com.team23.mdpremotecontroller.data.maze

data class Obstacle(
    val id: Int,
    val coordinate: Coordinate,
    val direction: Direction,
    val hasDirection: Boolean = true,
    val targetId: Int? = null
) {
    companion object {
        const val GRID_SIZE = 20
    }

}