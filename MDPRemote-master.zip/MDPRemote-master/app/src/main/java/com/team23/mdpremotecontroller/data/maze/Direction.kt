package com.team23.mdpremotecontroller.data.maze

enum class Direction {
    NORTH, EAST, SOUTH, WEST;

    fun rotate(): Direction = when (this) {
        NORTH -> EAST
        EAST -> SOUTH
        SOUTH -> WEST
        WEST -> NORTH
    }
}