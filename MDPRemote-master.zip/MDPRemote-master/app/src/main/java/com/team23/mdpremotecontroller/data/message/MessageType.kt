package com.team23.mdpremotecontroller.data.message

enum class MessageType {
    STATUS_UPDATE,    // For robot status updates (C.4)
    ROBOT_MOVEMENT,   // For movement commands (C.3)
    ROBOT_POSITION,   // For robot position updates (C.10)
    TARGET_UPDATE,    // For target identification (C.9)
    OBSTACLE_UPDATE,  // For obstacle placement/updates (C.6)
    TARGET_FACE,      // For updating target face position (C.7)
    TEXT_MESSAGE,     // For general text messages
    COMMAND          // For special commands
}