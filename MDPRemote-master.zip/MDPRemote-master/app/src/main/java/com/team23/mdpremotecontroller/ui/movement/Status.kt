package com.team23.mdpremotecontroller.ui.movement

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import com.team23.mdpremotecontroller.data.maze.MazeState
import com.team23.mdpremotecontroller.data.maze.RobotStatus
import com.team23.mdpremotecontroller.ui.theme.Pink40

@Composable
fun Status(
    movementState: MovementUiState,
    viewModel: MovementViewModel,
    mazeState: MazeState
){
    Column {
        Text("Status: ${movementState.currentStatus}")
        //If the robot exists
        if(mazeState.robot != null){
            //Include information of where robot is facing
            Text("Facing: ${mazeState.robot.direction}")
            Text("Coordinates: (${mazeState.robot.coordinate.x}, ${mazeState.robot.coordinate.y})")
        } else {
            Text("Position Unknown")
        }

        // Show either current elapsed time or final elapsed time
        val timeToDisplay = if (movementState.isActionRunning) {
            movementState.elapsedTime
        } else {
            movementState.finalElapsedTime
        }

        timeToDisplay?.let { time ->
            Text(
                text = viewModel.formatTime(time),
                style = MaterialTheme.typography.bodyLarge,
                color = Pink40
            )
        }
    }
}