package com.team23.mdpremotecontroller.ui.bluetooth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope

import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import com.team23.mdpremotecontroller.data.bluetooth.BluetoothController
import com.team23.mdpremotecontroller.data.bluetooth.BluetoothDevice
import com.team23.mdpremotecontroller.data.bluetooth.BluetoothDeviceDomain
import com.team23.mdpremotecontroller.data.bluetooth.BluetoothUiState
import com.team23.mdpremotecontroller.data.bluetooth.ConnectionResult
import com.team23.mdpremotecontroller.data.message.BluetoothMessage
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * ViewModel managing Bluetooth device scanning and connection state.
 * Handles UI state updates and user interactions for Bluetooth functionality.
 */
@HiltViewModel
class BluetoothViewModel @Inject constructor(
    private val bluetoothController: BluetoothController

):ViewModel(){
    private val _state = MutableStateFlow(BluetoothUiState())
    private val _messages = MutableSharedFlow<BluetoothMessage>()
    val messages = _messages.asSharedFlow()


    /**
     * Combined state stream of scanned devices, paired devices,
     * and current UI state
     */
    val state = combine(
        bluetoothController.scannedDevices,
        bluetoothController.pairedDevice,
        _state
    ) { scannedDevices, pairedDevices, state ->
        state.copy(
            scannedDevices = scannedDevices,
            pairedDevices = pairedDevices,
            messages = if(state.isConnected) state.messages else emptyList()
        )

    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), _state.value)

    private var deviceConnectionJob: Job? = null
    private var connectionMonitorJob: Job? = null
    private var reconnectionJob: Job? = null

    private var connectedDevice: BluetoothDevice? = null
    init{
        bluetoothController.isConnected.onEach {
            isConnected ->
            _state.update { it.copy(isConnected = isConnected) }
        }.launchIn(viewModelScope)

        bluetoothController.errors.onEach { error ->
            _state.update { it.copy(
                errorMessage = error
            ) }
        }.launchIn(viewModelScope)
    }

    fun connectToDevice(device: BluetoothDeviceDomain) {
        println("Connecting to device: ${device.name}")
        _state.update { it.copy(isConnecting = true) }
        deviceConnectionJob = bluetoothController
            .connectToDevice(device)
            .listen()
        connectedDevice = device
    }

    fun disconnectFromDevice() {
        println("Disconnected from device")
        deviceConnectionJob?.cancel()
        bluetoothController.closeConnection()
        reconnectionJob?.cancel()
        connectedDevice = null
        _state.update { it.copy(
            isConnecting = false,
            isConnected = false
        ) }
    }

    fun waitForIncomingConnections() {
        println("Starting server")
        _state.update { it.copy(isConnecting = true) }

        deviceConnectionJob = bluetoothController
            .startBluetoothServer()
            .listen()

        println("Started server")
        println("Current isConnecting value: ${_state.value.isConnecting}")
    }

    fun sendMessage(message: String) {
        println("Sending message: $message")
        viewModelScope.launch {
            //Pass our message string
            val bluetoothMessage = bluetoothController.trySendMessage(message)
            //Update our state and add it to our messages list
            if(bluetoothMessage != null) {
                _state.update { it.copy(
                    messages = it.messages + bluetoothMessage
                ) }
                //Emit the message
                _messages.emit(bluetoothMessage)
            }
        }
    }

    /** Initiates device scanning */
    fun startScan() {
        println("Starting scan")
        _state.update { it.copy(isScanning = true) }
        bluetoothController.startDiscovery()
    }

    private fun startConnectionMonitoring() {
        connectionMonitorJob?.cancel()
        connectionMonitorJob = viewModelScope?.launch {
            while(_state.value.isConnected){
                delay(2000)
                println("Connected")
            }
            println("Disconnected")
            tryReconnect()
        }
    }

    private fun tryReconnect(){
        reconnectionJob?.cancel()
        if(connectedDevice == null) return

        val maxRetries = 10
        reconnectionJob = viewModelScope.launch {
            //Wait to see if the other device will attempt to connect
            waitForIncomingConnections()

/*
            for(i in 1..maxRetries){
                if(_state.value.isConnected){
                    break
                }
                if(connectedDevice == null) break
                println("Trying to connect attempt $i")
                //Try to connect
                connectToDevice(connectedDevice!!)
                delay(2000)

            }*/
        }

    }

    /** Stops device scanning */
    fun stopScan() {
        println("Stopping scan")
        _state.update { it.copy(isScanning = false) }
        bluetoothController.stopDiscovery()
    }


    private fun Flow<ConnectionResult>.listen(): Job {
        return onEach { result ->
            when(result) {
                ConnectionResult.ConnectionEstablished -> {
                    _state.update { it.copy(
                        isConnected = true,
                        isConnecting = false,
                        isScanning = false,
                        errorMessage = null
                    ) }
                    println("Connection established!")
                    startConnectionMonitoring()
                }
                is ConnectionResult.TransferSucceeded -> {
                    _state.update { it.copy(
                        messages = it.messages + result.message
                    ) }
                    //Emit the message
                    _messages.emit(result.message)
                }
                is ConnectionResult.Error -> {
                    _state.update { it.copy(
                        isConnected = false,
                        isConnecting = false,
                        isScanning = false,
                        errorMessage = result.message
                    ) }
                }
            }
        }
            .catch { throwable ->
                bluetoothController.closeConnection()
                _state.update { it.copy(
                    isConnected = false,
                    isScanning = false,
                    isConnecting = false,
                ) }
            }
            .launchIn(viewModelScope)
    }

    /*
    * Release all resources when the viewmodel leaves the backstack
     */
    override fun onCleared() {
        super.onCleared()
        connectedDevice = null
        reconnectionJob?.cancel()
        bluetoothController.release()
    }
}