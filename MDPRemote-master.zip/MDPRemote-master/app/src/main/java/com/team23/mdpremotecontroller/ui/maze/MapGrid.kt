package com.team23.mdpremotecontroller.ui.maze

import androidx.compose.ui.text.TextMeasurer
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.team23.mdpremotecontroller.R
import com.team23.mdpremotecontroller.data.maze.Coordinate
import com.team23.mdpremotecontroller.data.maze.Direction
import com.team23.mdpremotecontroller.data.maze.Obstacle
import com.team23.mdpremotecontroller.data.maze.RobotState
import com.team23.mdpremotecontroller.ui.theme.Pink40
import com.team23.mdpremotecontroller.ui.theme.Teal40
import com.team23.mdpremotecontroller.ui.theme.Teal80

@Composable
fun MapGrid(
    modifier: Modifier = Modifier,
    viewModel: MapViewModel
) {
    val state by viewModel.mazeState.collectAsState()
    val context = LocalContext.current
    val textMeasurer = rememberTextMeasurer()

    // Load robot images for different directions
    val robotNorth = remember { ImageBitmap.imageResource(context.resources, R.drawable.car_up) }
    val robotEast = remember { ImageBitmap.imageResource(context.resources, R.drawable.car_right) }
    val robotSouth = remember { ImageBitmap.imageResource(context.resources, R.drawable.car_down) }
    val robotWest = remember { ImageBitmap.imageResource(context.resources, R.drawable.car_left) }



    Box(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(
            modifier = Modifier
                .aspectRatio(1f)
                .fillMaxSize()
                .pointerInput(Unit){
                    detectDragGestures(
                        onDragStart = { offset ->
                            val coordinate = offsetToGridCoordinate(offset, size.width)
                            println("Drag start at $coordinate")
                            viewModel.onDragStart(coordinate)
                        },
                        onDragEnd = {
                            println("Drag end")
                            viewModel.onDragEnd()
                        },
                        onDragCancel = {
                            println("Drag cancel")
                            viewModel.onDragEnd()
                        },
                        onDrag = {
                            change, dragAmount ->
                            println("change: $change dragAmount: $dragAmount")
                            val coordinate = offsetToGridCoordinate(change.position, size.width)
                            viewModel.onDrag(coordinate)
                            change.consume()

                        },
                    )
                }.pointerInput(Unit){
                    detectTapGestures(
                        onTap = { offset ->
                            val coordinate = offsetToGridCoordinate(offset, size.width)
                            println("Tap at $coordinate")
                            viewModel.onTap(coordinate)
                        },
                        onLongPress = { offset-> 
                            val coordinate = offsetToGridCoordinate(offset, size.width)
                            println("Long press at $coordinate")
                            viewModel.onLongPress(coordinate)
                        }
                    )
                }
        ) {
            val cellSize = size.width / Obstacle.GRID_SIZE

            // Draw grid
            drawGrid(cellSize)




            // Draw obstacles
            state.obstacles.forEach { obstacle ->
                drawObstacle(
                    obstacle = obstacle,
                    cellSize = cellSize,
                    textMeasurer = textMeasurer
                )
            }

            // Draw robot if present
            state.robot?.let { robot ->
                drawRobot(
                    coordinate = robot.coordinate,
                    direction = robot.direction,
                    cellSize = cellSize,
                    robotImages = mapOf(
                        Direction.NORTH to robotNorth,
                        Direction.EAST to robotEast,
                        Direction.SOUTH to robotSouth,
                        Direction.WEST to robotWest
                    )
                )
            }
        }
    }
}

private fun DrawScope.drawGrid(cellSize: Float) {
    for (i in 0..Obstacle.GRID_SIZE) {
        // Vertical lines
        drawLine(
            color = Color.Gray,
            start = Offset(i * cellSize, 0f),
            end = Offset(i * cellSize, size.height)
        )
        // Horizontal lines
        drawLine(
            color = Color.Gray,
            start = Offset(0f, i * cellSize),
            end = Offset(size.width, i * cellSize)
        )
    }
}

private fun DrawScope.drawObstacle(
    obstacle: Obstacle,
    cellSize: Float,
    textMeasurer: TextMeasurer
) {
    val x = obstacle.coordinate.x * cellSize
    val y = (Obstacle.GRID_SIZE - 1 - obstacle.coordinate.y) * cellSize

    // Draw obstacle square
    drawRect(
        color = if (obstacle.targetId == null){Color.Gray} else {Teal40},
        topLeft = Offset(x, y),
        size = Size(cellSize, cellSize)
    )

    // Draw obstacle number
    val text = obstacle.targetId?.toString() ?: obstacle.id.toString()
    val textLayout = textMeasurer.measure(
        text = text,
        style = TextStyle(
            color = Color.White,
            fontSize = if(obstacle.targetId == null) 12.sp else 16.sp
        )
    )

    drawText(
        textLayoutResult = textLayout,
        topLeft = Offset(
            x + (cellSize - textLayout.size.width) / 2,
            y + (cellSize - textLayout.size.height) / 2
        ),
        color = Color.White
    )

    // Draw target direction indicator if present
    if(!obstacle.hasDirection){
        //Do not draw direction
        return
    }
    val direction = obstacle.direction
    val indicatorSize = cellSize * 0.2f
    val sideLength = cellSize * 0.8f

    val indicatorColor = Pink40
    when (direction) {
        Direction.NORTH -> drawRect(
            color = indicatorColor,
            topLeft = Offset(x + (cellSize - indicatorSize) / 2, y),
            size = Size(indicatorSize, sideLength / 4)
        )
        Direction.EAST -> drawRect(
            color = indicatorColor,
            topLeft = Offset(x + cellSize - sideLength / 4, y + (cellSize - indicatorSize) / 2),
            size = Size(sideLength / 4, indicatorSize)
        )
        Direction.SOUTH -> drawRect(
            color = indicatorColor,
            topLeft = Offset(x + (cellSize - indicatorSize) / 2, y + cellSize - sideLength / 4),
            size = Size(indicatorSize, sideLength / 4)
        )
        Direction.WEST -> drawRect(
            color = indicatorColor,
            topLeft = Offset(x, y + (cellSize - indicatorSize) / 2),
            size = Size(sideLength / 4, indicatorSize)
        )
    }
}

private fun DrawScope.drawRobot(
    coordinate: Coordinate,
    direction: Direction,
    cellSize: Float,
    robotImages: Map<Direction, ImageBitmap>
) {
    val robotSize = cellSize.toInt() * RobotState.SIZE
    val x = (coordinate.x - 1) * cellSize // Offset by 1 cell since robot coordinate is center
    val y = (Obstacle.GRID_SIZE - 1 - coordinate.y - 1) * cellSize // Adjust for coordinate system and offset

    // Get the appropriate robot image based on direction
    val robotImage = robotImages[direction] ?: return

    // Calculate the center position for the robot
    val centerX = x + (robotSize / 2)
    val centerY = y + (robotSize / 2)

    // Draw the robot image
    drawImage(
        image = robotImage,
        dstOffset = IntOffset(x.toInt(), y.toInt()),
        dstSize = IntSize(robotSize, robotSize)
    )


}

private fun offsetToGridCoordinate(offset: Offset, canvasSize: Int): Coordinate {
    val cellSize = canvasSize / Obstacle.GRID_SIZE
    println("Cell size: $cellSize")
    // Convert screen coordinates to grid coordinates
    val gridX = (offset.x / cellSize).toInt()

    // Since the grid is drawn with y=0 at the top but we want coordinates with y=0 at the bottom
    val gridY = Obstacle.GRID_SIZE - 1 - (offset.y / cellSize).toInt()

    println("Grid coordinates: ($gridX, $gridY)")
    return Coordinate(
        x = gridX,
        y = gridY
    )
}
