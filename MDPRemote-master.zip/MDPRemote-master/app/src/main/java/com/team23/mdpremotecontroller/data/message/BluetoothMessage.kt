package com.team23.mdpremotecontroller.data.message

import com.team23.mdpremotecontroller.data.maze.Obstacle
import com.team23.mdpremotecontroller.data.maze.RobotState

data class BluetoothMessage(
    val type: MessageType = MessageType.TEXT_MESSAGE,
    val message: String,
    val senderName: String,
    val isFromLocalUser: Boolean,
    val metadata: Map<String, String> = emptyMap()
) {
    companion object {
        fun createRobotPosition(robotState: RobotState, senderName: String): BluetoothMessage {
            return BluetoothMessage(
                type = MessageType.ROBOT_POSITION,
                message = "ROBOT is now at ${robotState.coordinate.x},${robotState.coordinate.y}, facing ${robotState.direction}",
                senderName = senderName,
                isFromLocalUser = true,
                metadata = mapOf(
                    "x" to robotState.coordinate.x.toString(),
                    "y" to robotState.coordinate.y.toString(),
                    "direction" to robotState.direction.toString()
                )
            )
        }

        fun createObstacleUpdate(obstacle: Obstacle, senderName: String): BluetoothMessage {
            return BluetoothMessage(
                type = MessageType.OBSTACLE_UPDATE,
                message = "OBSTACLE,${obstacle.coordinate.x},${obstacle.coordinate.y},${obstacle.id},${obstacle.direction}",
                senderName = senderName,
                isFromLocalUser = true,
                metadata = mapOf(
                    "x" to obstacle.coordinate.x.toString(),
                    "y" to obstacle.coordinate.y.toString(),
                    "number" to obstacle.id.toString(),
                    "direction" to obstacle.direction.toString()
                )
            )
        }

        fun createTargetUpdate(obstacleNumber: Int, targetId: Int, senderName: String): BluetoothMessage {
            return BluetoothMessage(
                type = MessageType.TARGET_UPDATE,
                message = "TARGET,$obstacleNumber,$targetId",
                senderName = senderName,
                isFromLocalUser = true,
                metadata = mapOf(
                    "obstacleNumber" to obstacleNumber.toString(),
                    "targetId" to targetId.toString()
                )
            )
        }

        fun createStatusUpdate(status: String, senderName: String): BluetoothMessage {
            return BluetoothMessage(
                type = MessageType.STATUS_UPDATE,
                message = "STATUS,$status",
                senderName = senderName,
                isFromLocalUser = true,
                metadata = mapOf("status" to status)
            )
        }
    }
}