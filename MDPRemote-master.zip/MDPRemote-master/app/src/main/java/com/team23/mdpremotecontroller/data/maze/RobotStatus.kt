package com.team23.mdpremotecontroller.data.maze

enum class RobotStatus {
    IDLE,
    MOVING,
    SCANNING,
    IMAGE_PROCESSING,
    PATH_PLANNING,
    ERROR;

    val isActive: Boolean
        get() = this != IDLE && this != ERROR
}