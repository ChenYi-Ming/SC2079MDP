package com.team23.mdpremotecontroller.data.maze

enum class PlaceState {
    None,
    Obstacle,
    Car
}