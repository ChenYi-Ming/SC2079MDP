package com.team23.mdpremotecontroller.data.bluetooth

typealias BluetoothDeviceDomain = BluetoothDevice
data class BluetoothDevice(
    val name: String?,
    val address: String,

)