package com.team23.mdpremotecontroller.data.maze

data class Coordinate(
    val x: Int,
    val y: Int
)
