package com.team23.mdpremotecontroller.ui.maze

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.team23.mdpremotecontroller.R
import com.team23.mdpremotecontroller.data.maze.PlaceState
import com.team23.mdpremotecontroller.ui.theme.Pink40
import com.team23.mdpremotecontroller.ui.theme.Teal40

@Composable
fun MapScreen(
    modifier: Modifier = Modifier,
    viewModel: MapViewModel
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Teal40)
            .padding(16.dp)
    ) {
        // Map Grid Area
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(Color.White)
                .padding(16.dp)
        ) {
            MapGrid(viewModel = viewModel)
        }

        // Control Buttons
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {


            DeployButton(
                icon = R.drawable.obstacle,
                text = "Place Obstacle",
                onClick = {viewModel.selectPlacementButton(PlaceState.Obstacle)},
                modifier = Modifier.size(120.dp),
                isSelected = (viewModel.placeState.collectAsState().value == PlaceState.Obstacle)
            )


            DeployButton(
                icon = R.drawable.car_down,
                text = "Deploy Car",
                onClick = { viewModel.selectPlacementButton(PlaceState.Car)},
                modifier = Modifier.size(120.dp),
                isSelected = (viewModel.placeState.collectAsState().value == PlaceState.Car)
            )

            Column(
                modifier = Modifier.weight(1f).padding(start = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { viewModel.saveMap() },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Pink40),

                ) {
                    Text("Save Map")
                }
                Button(
                    onClick = { viewModel.loadMap() },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Pink40),

                    ) {
                    Text("Load Map")
                }

                Button(
                    onClick = { viewModel.resetMap() },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Pink40),

                ) {
                    Text("Reset Map")
                }
            }
        }

        // Coordinates Display
        CoordinateDisplay(
            mazeState = viewModel.mazeState.collectAsState().value,
            modifier = Modifier.fillMaxWidth()
        )
    }
}