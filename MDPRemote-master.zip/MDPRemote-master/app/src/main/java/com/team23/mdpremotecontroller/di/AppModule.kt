package com.team23.mdpremotecontroller.di

import android.content.Context
import com.team23.mdpremotecontroller.data.bluetooth.AndroidBluetoothController
import com.team23.mdpremotecontroller.data.bluetooth.BluetoothController
import com.team23.mdpremotecontroller.ui.bluetooth.BluetoothViewModel
import com.team23.mdpremotecontroller.ui.maze.MapViewModel
import com.team23.mdpremotecontroller.ui.movement.MovementViewModel
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideBluetoothController(@ApplicationContext context: Context): BluetoothController {
        return AndroidBluetoothController(context)
    }

    @Provides
    @Singleton
    fun provideBluetoothViewModel(
        bluetoothController: BluetoothController
    ): BluetoothViewModel {
        return BluetoothViewModel(bluetoothController)
    }

}