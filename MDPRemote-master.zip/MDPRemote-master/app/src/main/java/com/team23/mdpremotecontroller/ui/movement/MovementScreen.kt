package com.team23.mdpremotecontroller.ui.movement

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.team23.mdpremotecontroller.R
import com.team23.mdpremotecontroller.data.bluetooth.BluetoothUiState
import com.team23.mdpremotecontroller.data.message.MessageType
import com.team23.mdpremotecontroller.data.message.RobotCommand
import com.team23.mdpremotecontroller.ui.maze.MapViewModel
import com.team23.mdpremotecontroller.ui.theme.Pink40
import com.team23.mdpremotecontroller.ui.theme.Teal40

@Composable
fun MovementScreen(
    state: BluetoothUiState,
    viewModel: MovementViewModel = hiltViewModel(),
    mapViewModel: MapViewModel = hiltViewModel(),
    modifier: Modifier = Modifier
) {
    val movementState by viewModel.uiState.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Teal40)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Status Bar with Stopwatch
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF98F1E8))
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .background(Teal40, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Image(ImageBitmap.imageResource(R.drawable.triangleguard), contentDescription = "Driver")
                }
                Status(
                    movementState = movementState,
                    viewModel = viewModel,
                    mazeState = mapViewModel.mazeState.collectAsState().value
                )
            }
        }

        // Movement Controls
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Grid of movement buttons
            MovementControlGrid(
                onForward = { viewModel.sendMovementCommand(RobotCommand.FORWARD) },
                onBackward = { viewModel.sendMovementCommand(RobotCommand.REVERSE) },
                onForwardLeft = { viewModel.sendMovementCommand(RobotCommand.FORWARD_LEFT) },
                onForwardRight = { viewModel.sendMovementCommand(RobotCommand.FORWARD_RIGHT) },
                onBackwardLeft = { viewModel.sendMovementCommand(RobotCommand.BACKWARD_LEFT) },
                onBackwardRight = { viewModel.sendMovementCommand(RobotCommand.BACKWARD_RIGHT) }
            )
        }

        // Action Buttons
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = {
                    if (movementState.isActionRunning) {
                        viewModel.stopAction()
                    } else {
                        viewModel.startExploration()
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (movementState.currentAction == "Explore") Color.Red else Pink40
                ),
                modifier = Modifier.fillMaxWidth(0.8f)
            ) {
                Text(
                    text = if (movementState.currentAction == "Explore") "Stop Exploration" else "Explore Area",
                    fontSize = 16.sp
                )
            }

            Button(
                onClick = {
                    if (movementState.isActionRunning) {
                        viewModel.stopAction()
                    } else {
                        viewModel.startFastestPath()
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (movementState.currentAction == "Fastest") Color.Red else Pink40
                ),
                modifier = Modifier.fillMaxWidth(0.8f)
            ) {
                Text(
                    text = if (movementState.currentAction == "Fastest") "Stop Path" else "Fastest Path",
                    fontSize = 16.sp
                )
            }
        }
    }
}